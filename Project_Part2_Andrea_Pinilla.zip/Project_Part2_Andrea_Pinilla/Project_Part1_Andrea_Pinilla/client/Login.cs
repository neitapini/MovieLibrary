﻿using Project_Part1_Andrea_Pinilla.client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Project_Part1_Andrea_Pinilla
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void Login_BackgroundImageChanged(object sender, EventArgs e)
        {
            
        }

        private void Login_Load(object sender, EventArgs e)
        {
            this.textBoxLoginId.Focus();
        }

        private void buttonLogin_Click(object sender, EventArgs e)
        {
            if (this.textBoxLoginId.Text == "admin" && this.textBoxPassword.Text == "123")
            {
                MovieLibraryForm myMainForm = new MovieLibraryForm();
                myMainForm.ShowDialog();
            }
            else { MessageBox.Show("Wrong Student ID or PASSWORD"); }
        }

        private void buttonLoginReset_Click(object sender, EventArgs e)
        {
            this.textBoxLoginId.Text = "";
            this.textBoxPassword.Text = "";
            this.textBoxLoginId.Focus();
        }

        private void buttonLogout_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
