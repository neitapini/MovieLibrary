﻿namespace Project_Part1_Andrea_Pinilla.client
{
    partial class MovieLibraryForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxTitle = new System.Windows.Forms.TextBox();
            this.labelTitle = new System.Windows.Forms.Label();
            this.textBoxHours = new System.Windows.Forms.TextBox();
            this.labelDuration = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxMinutes = new System.Windows.Forms.TextBox();
            this.labelGenre = new System.Windows.Forms.Label();
            this.comboBoxGenre = new System.Windows.Forms.ComboBox();
            this.labelCountry = new System.Windows.Forms.Label();
            this.textBoxCountry = new System.Windows.Forms.TextBox();
            this.labelYear = new System.Windows.Forms.Label();
            this.textBoxYear = new System.Windows.Forms.TextBox();
            this.labelDirector = new System.Windows.Forms.Label();
            this.textBoxDirector = new System.Windows.Forms.TextBox();
            this.textBoxActor = new System.Windows.Forms.TextBox();
            this.labelActor = new System.Windows.Forms.Label();
            this.labelLenguage = new System.Windows.Forms.Label();
            this.comboBoxLenguage = new System.Windows.Forms.ComboBox();
            this.labelCloseCaption = new System.Windows.Forms.Label();
            this.comboBoxCloseCaption = new System.Windows.Forms.ComboBox();
            this.labelCCLenguage = new System.Windows.Forms.Label();
            this.comboBoxCCLeng = new System.Windows.Forms.ComboBox();
            this.labelAward = new System.Windows.Forms.Label();
            this.comboBoxAward = new System.Windows.Forms.ComboBox();
            this.buttonAdd = new System.Windows.Forms.Button();
            this.buttonDisplay = new System.Windows.Forms.Button();
            this.buttonUpdate = new System.Windows.Forms.Button();
            this.buttonDelete = new System.Windows.Forms.Button();
            this.buttonReset = new System.Windows.Forms.Button();
            this.buttonSearch = new System.Windows.Forms.Button();
            this.buttonExit = new System.Windows.Forms.Button();
            this.textBoxSearch = new System.Windows.Forms.TextBox();
            this.labelSearchMovie = new System.Windows.Forms.Label();
            this.labelId = new System.Windows.Forms.Label();
            this.textBoxId = new System.Windows.Forms.TextBox();
            this.listBoxMovieInfo = new System.Windows.Forms.ListBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.comboBoxDirector = new System.Windows.Forms.ComboBox();
            this.comboBoxActor = new System.Windows.Forms.ComboBox();
            this.listViewMovies = new System.Windows.Forms.ListView();
            this.columnHeaderId = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderTitle = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderDuration = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderGenre = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderCountry = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderYear = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderDirector = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderActor = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderAudio = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderCC = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderCCLeng = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderAward = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.buttonWriteTxt = new System.Windows.Forms.Button();
            this.buttonReadTxt = new System.Windows.Forms.Button();
            this.buttonWriteToBinFIle = new System.Windows.Forms.Button();
            this.buttonReadFromBinFile = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Broadway", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label1.Location = new System.Drawing.Point(312, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(170, 24);
            this.label1.TabIndex = 8;
            this.label1.Text = "Movie Library";
            // 
            // textBoxTitle
            // 
            this.textBoxTitle.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxTitle.Location = new System.Drawing.Point(351, 64);
            this.textBoxTitle.Name = "textBoxTitle";
            this.textBoxTitle.Size = new System.Drawing.Size(310, 21);
            this.textBoxTitle.TabIndex = 39;
            this.textBoxTitle.TextChanged += new System.EventHandler(this.textBoxTitle_TextChanged);
            // 
            // labelTitle
            // 
            this.labelTitle.AutoSize = true;
            this.labelTitle.BackColor = System.Drawing.Color.Transparent;
            this.labelTitle.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.labelTitle.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTitle.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelTitle.Location = new System.Drawing.Point(279, 67);
            this.labelTitle.Name = "labelTitle";
            this.labelTitle.Size = new System.Drawing.Size(73, 15);
            this.labelTitle.TabIndex = 9;
            this.labelTitle.Text = "Movie Title:  ";
            // 
            // textBoxHours
            // 
            this.textBoxHours.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxHours.Location = new System.Drawing.Point(212, 96);
            this.textBoxHours.Name = "textBoxHours";
            this.textBoxHours.Size = new System.Drawing.Size(42, 21);
            this.textBoxHours.TabIndex = 12;
            this.textBoxHours.Tag = "";
            this.textBoxHours.TextChanged += new System.EventHandler(this.textBoxHours_TextChanged);
            this.textBoxHours.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxHours_KeyPress);
            // 
            // labelDuration
            // 
            this.labelDuration.AutoSize = true;
            this.labelDuration.BackColor = System.Drawing.Color.Transparent;
            this.labelDuration.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.labelDuration.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDuration.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelDuration.Location = new System.Drawing.Point(133, 103);
            this.labelDuration.Name = "labelDuration";
            this.labelDuration.Size = new System.Drawing.Size(65, 15);
            this.labelDuration.TabIndex = 11;
            this.labelDuration.Text = "Duration :  ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(264, 103);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(12, 15);
            this.label2.TabIndex = 11;
            this.label2.Text = "/";
            // 
            // textBoxMinutes
            // 
            this.textBoxMinutes.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxMinutes.Location = new System.Drawing.Point(282, 96);
            this.textBoxMinutes.Name = "textBoxMinutes";
            this.textBoxMinutes.Size = new System.Drawing.Size(41, 21);
            this.textBoxMinutes.TabIndex = 12;
            this.textBoxMinutes.Tag = "";
            this.textBoxMinutes.TextChanged += new System.EventHandler(this.textBoxMinutes_TextChanged);
            this.textBoxMinutes.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxMinutes_KeyPress);
            // 
            // labelGenre
            // 
            this.labelGenre.AutoSize = true;
            this.labelGenre.BackColor = System.Drawing.Color.Transparent;
            this.labelGenre.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.labelGenre.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelGenre.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelGenre.Location = new System.Drawing.Point(481, 103);
            this.labelGenre.Name = "labelGenre";
            this.labelGenre.Size = new System.Drawing.Size(53, 15);
            this.labelGenre.TabIndex = 11;
            this.labelGenre.Text = "Genre :  ";
            // 
            // comboBoxGenre
            // 
            this.comboBoxGenre.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxGenre.FormattingEnabled = true;
            this.comboBoxGenre.Location = new System.Drawing.Point(540, 97);
            this.comboBoxGenre.Name = "comboBoxGenre";
            this.comboBoxGenre.Size = new System.Drawing.Size(121, 24);
            this.comboBoxGenre.TabIndex = 13;
            // 
            // labelCountry
            // 
            this.labelCountry.AutoSize = true;
            this.labelCountry.BackColor = System.Drawing.Color.Transparent;
            this.labelCountry.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.labelCountry.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCountry.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelCountry.Location = new System.Drawing.Point(133, 168);
            this.labelCountry.Name = "labelCountry";
            this.labelCountry.Size = new System.Drawing.Size(61, 15);
            this.labelCountry.TabIndex = 11;
            this.labelCountry.Text = "Country :  ";
            // 
            // textBoxCountry
            // 
            this.textBoxCountry.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxCountry.Location = new System.Drawing.Point(212, 162);
            this.textBoxCountry.Name = "textBoxCountry";
            this.textBoxCountry.Size = new System.Drawing.Size(145, 21);
            this.textBoxCountry.TabIndex = 14;
            // 
            // labelYear
            // 
            this.labelYear.AutoSize = true;
            this.labelYear.BackColor = System.Drawing.Color.Transparent;
            this.labelYear.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.labelYear.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelYear.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelYear.Location = new System.Drawing.Point(348, 103);
            this.labelYear.Name = "labelYear";
            this.labelYear.Size = new System.Drawing.Size(44, 15);
            this.labelYear.TabIndex = 15;
            this.labelYear.Text = "Year :  ";
            // 
            // textBoxYear
            // 
            this.textBoxYear.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxYear.Location = new System.Drawing.Point(398, 96);
            this.textBoxYear.Name = "textBoxYear";
            this.textBoxYear.Size = new System.Drawing.Size(50, 21);
            this.textBoxYear.TabIndex = 16;
            this.textBoxYear.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxYear_KeyPress);
            // 
            // labelDirector
            // 
            this.labelDirector.AutoSize = true;
            this.labelDirector.BackColor = System.Drawing.Color.Transparent;
            this.labelDirector.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.labelDirector.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDirector.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelDirector.Location = new System.Drawing.Point(133, 137);
            this.labelDirector.Name = "labelDirector";
            this.labelDirector.Size = new System.Drawing.Size(62, 15);
            this.labelDirector.TabIndex = 17;
            this.labelDirector.Text = "Director :  ";
            // 
            // textBoxDirector
            // 
            this.textBoxDirector.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxDirector.Location = new System.Drawing.Point(212, 131);
            this.textBoxDirector.Name = "textBoxDirector";
            this.textBoxDirector.Size = new System.Drawing.Size(21, 21);
            this.textBoxDirector.TabIndex = 18;
            this.textBoxDirector.Visible = false;
            // 
            // textBoxActor
            // 
            this.textBoxActor.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxActor.Location = new System.Drawing.Point(484, 131);
            this.textBoxActor.Name = "textBoxActor";
            this.textBoxActor.Size = new System.Drawing.Size(23, 21);
            this.textBoxActor.TabIndex = 20;
            this.textBoxActor.Visible = false;
            // 
            // labelActor
            // 
            this.labelActor.AutoSize = true;
            this.labelActor.BackColor = System.Drawing.Color.Transparent;
            this.labelActor.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.labelActor.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelActor.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelActor.Location = new System.Drawing.Point(430, 137);
            this.labelActor.Name = "labelActor";
            this.labelActor.Size = new System.Drawing.Size(48, 15);
            this.labelActor.TabIndex = 19;
            this.labelActor.Text = "Actor :  ";
            // 
            // labelLenguage
            // 
            this.labelLenguage.AutoSize = true;
            this.labelLenguage.BackColor = System.Drawing.Color.Transparent;
            this.labelLenguage.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.labelLenguage.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelLenguage.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelLenguage.Location = new System.Drawing.Point(133, 198);
            this.labelLenguage.Name = "labelLenguage";
            this.labelLenguage.Size = new System.Drawing.Size(51, 15);
            this.labelLenguage.TabIndex = 21;
            this.labelLenguage.Text = "Audio :  ";
            // 
            // comboBoxLenguage
            // 
            this.comboBoxLenguage.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxLenguage.FormattingEnabled = true;
            this.comboBoxLenguage.Location = new System.Drawing.Point(212, 193);
            this.comboBoxLenguage.Name = "comboBoxLenguage";
            this.comboBoxLenguage.Size = new System.Drawing.Size(123, 24);
            this.comboBoxLenguage.TabIndex = 22;
            // 
            // labelCloseCaption
            // 
            this.labelCloseCaption.AutoSize = true;
            this.labelCloseCaption.BackColor = System.Drawing.Color.Transparent;
            this.labelCloseCaption.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.labelCloseCaption.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCloseCaption.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelCloseCaption.Location = new System.Drawing.Point(355, 195);
            this.labelCloseCaption.Name = "labelCloseCaption";
            this.labelCloseCaption.Size = new System.Drawing.Size(35, 15);
            this.labelCloseCaption.TabIndex = 23;
            this.labelCloseCaption.Text = "CC :  ";
            // 
            // comboBoxCloseCaption
            // 
            this.comboBoxCloseCaption.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxCloseCaption.FormattingEnabled = true;
            this.comboBoxCloseCaption.Location = new System.Drawing.Point(394, 193);
            this.comboBoxCloseCaption.Name = "comboBoxCloseCaption";
            this.comboBoxCloseCaption.Size = new System.Drawing.Size(80, 24);
            this.comboBoxCloseCaption.TabIndex = 24;
            // 
            // labelCCLenguage
            // 
            this.labelCCLenguage.AutoSize = true;
            this.labelCCLenguage.BackColor = System.Drawing.Color.Transparent;
            this.labelCCLenguage.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.labelCCLenguage.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCCLenguage.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelCCLenguage.Location = new System.Drawing.Point(481, 195);
            this.labelCCLenguage.Name = "labelCCLenguage";
            this.labelCCLenguage.Size = new System.Drawing.Size(64, 15);
            this.labelCCLenguage.TabIndex = 25;
            this.labelCCLenguage.Text = "CC Leng :  ";
            // 
            // comboBoxCCLeng
            // 
            this.comboBoxCCLeng.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxCCLeng.FormattingEnabled = true;
            this.comboBoxCCLeng.Location = new System.Drawing.Point(540, 196);
            this.comboBoxCCLeng.Name = "comboBoxCCLeng";
            this.comboBoxCCLeng.Size = new System.Drawing.Size(121, 24);
            this.comboBoxCCLeng.TabIndex = 26;
            // 
            // labelAward
            // 
            this.labelAward.AutoSize = true;
            this.labelAward.BackColor = System.Drawing.Color.Transparent;
            this.labelAward.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.labelAward.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAward.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelAward.Location = new System.Drawing.Point(424, 168);
            this.labelAward.Name = "labelAward";
            this.labelAward.Size = new System.Drawing.Size(54, 15);
            this.labelAward.TabIndex = 27;
            this.labelAward.Text = "Award :  ";
            // 
            // comboBoxAward
            // 
            this.comboBoxAward.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxAward.FormattingEnabled = true;
            this.comboBoxAward.Location = new System.Drawing.Point(484, 162);
            this.comboBoxAward.Name = "comboBoxAward";
            this.comboBoxAward.Size = new System.Drawing.Size(177, 24);
            this.comboBoxAward.TabIndex = 28;
            // 
            // buttonAdd
            // 
            this.buttonAdd.BackColor = System.Drawing.Color.Gold;
            this.buttonAdd.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.buttonAdd.FlatAppearance.BorderSize = 3;
            this.buttonAdd.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonAdd.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAdd.ForeColor = System.Drawing.Color.Maroon;
            this.buttonAdd.Image = global::Project_Part1_Andrea_Pinilla.Properties.Resources.download;
            this.buttonAdd.Location = new System.Drawing.Point(136, 232);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new System.Drawing.Size(75, 23);
            this.buttonAdd.TabIndex = 29;
            this.buttonAdd.Text = "Add";
            this.buttonAdd.UseVisualStyleBackColor = false;
            this.buttonAdd.Click += new System.EventHandler(this.buttonAdd_Click);
            // 
            // buttonDisplay
            // 
            this.buttonDisplay.BackColor = System.Drawing.Color.Gold;
            this.buttonDisplay.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.buttonDisplay.FlatAppearance.BorderSize = 3;
            this.buttonDisplay.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonDisplay.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonDisplay.ForeColor = System.Drawing.Color.Maroon;
            this.buttonDisplay.Image = global::Project_Part1_Andrea_Pinilla.Properties.Resources.download;
            this.buttonDisplay.Location = new System.Drawing.Point(248, 232);
            this.buttonDisplay.Name = "buttonDisplay";
            this.buttonDisplay.Size = new System.Drawing.Size(75, 23);
            this.buttonDisplay.TabIndex = 30;
            this.buttonDisplay.Text = "Display";
            this.buttonDisplay.UseVisualStyleBackColor = false;
            this.buttonDisplay.Click += new System.EventHandler(this.buttonDisplay_Click);
            // 
            // buttonUpdate
            // 
            this.buttonUpdate.BackColor = System.Drawing.Color.Gold;
            this.buttonUpdate.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.buttonUpdate.FlatAppearance.BorderSize = 3;
            this.buttonUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonUpdate.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonUpdate.ForeColor = System.Drawing.Color.Maroon;
            this.buttonUpdate.Image = global::Project_Part1_Andrea_Pinilla.Properties.Resources.download;
            this.buttonUpdate.Location = new System.Drawing.Point(358, 232);
            this.buttonUpdate.Name = "buttonUpdate";
            this.buttonUpdate.Size = new System.Drawing.Size(75, 23);
            this.buttonUpdate.TabIndex = 31;
            this.buttonUpdate.Text = "Update";
            this.buttonUpdate.UseVisualStyleBackColor = false;
            this.buttonUpdate.Click += new System.EventHandler(this.buttonUpdate_Click);
            // 
            // buttonDelete
            // 
            this.buttonDelete.BackColor = System.Drawing.Color.Gold;
            this.buttonDelete.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.buttonDelete.FlatAppearance.BorderSize = 3;
            this.buttonDelete.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonDelete.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonDelete.ForeColor = System.Drawing.Color.Maroon;
            this.buttonDelete.Image = global::Project_Part1_Andrea_Pinilla.Properties.Resources.download;
            this.buttonDelete.Location = new System.Drawing.Point(470, 232);
            this.buttonDelete.Name = "buttonDelete";
            this.buttonDelete.Size = new System.Drawing.Size(75, 23);
            this.buttonDelete.TabIndex = 32;
            this.buttonDelete.Text = "Delete";
            this.buttonDelete.UseVisualStyleBackColor = false;
            this.buttonDelete.Click += new System.EventHandler(this.buttonDelete_Click);
            // 
            // buttonReset
            // 
            this.buttonReset.BackColor = System.Drawing.Color.Gold;
            this.buttonReset.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.buttonReset.FlatAppearance.BorderSize = 3;
            this.buttonReset.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonReset.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonReset.ForeColor = System.Drawing.Color.Maroon;
            this.buttonReset.Image = global::Project_Part1_Andrea_Pinilla.Properties.Resources.download;
            this.buttonReset.Location = new System.Drawing.Point(586, 232);
            this.buttonReset.Name = "buttonReset";
            this.buttonReset.Size = new System.Drawing.Size(75, 23);
            this.buttonReset.TabIndex = 33;
            this.buttonReset.Text = "Reset";
            this.buttonReset.UseVisualStyleBackColor = false;
            this.buttonReset.Click += new System.EventHandler(this.buttonReset_Click);
            // 
            // buttonSearch
            // 
            this.buttonSearch.BackColor = System.Drawing.Color.Gold;
            this.buttonSearch.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.buttonSearch.FlatAppearance.BorderSize = 3;
            this.buttonSearch.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonSearch.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSearch.ForeColor = System.Drawing.Color.Maroon;
            this.buttonSearch.Image = global::Project_Part1_Andrea_Pinilla.Properties.Resources.download;
            this.buttonSearch.Location = new System.Drawing.Point(248, 286);
            this.buttonSearch.Name = "buttonSearch";
            this.buttonSearch.Size = new System.Drawing.Size(75, 23);
            this.buttonSearch.TabIndex = 34;
            this.buttonSearch.Text = "Search";
            this.buttonSearch.UseVisualStyleBackColor = false;
            this.buttonSearch.Click += new System.EventHandler(this.buttonSearch_Click);
            // 
            // buttonExit
            // 
            this.buttonExit.BackColor = System.Drawing.Color.Gold;
            this.buttonExit.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.buttonExit.FlatAppearance.BorderSize = 3;
            this.buttonExit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonExit.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonExit.ForeColor = System.Drawing.Color.Maroon;
            this.buttonExit.Image = global::Project_Part1_Andrea_Pinilla.Properties.Resources.download;
            this.buttonExit.Location = new System.Drawing.Point(586, 285);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(75, 23);
            this.buttonExit.TabIndex = 35;
            this.buttonExit.Text = "Exit";
            this.buttonExit.UseVisualStyleBackColor = false;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // textBoxSearch
            // 
            this.textBoxSearch.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxSearch.Location = new System.Drawing.Point(136, 287);
            this.textBoxSearch.Name = "textBoxSearch";
            this.textBoxSearch.Size = new System.Drawing.Size(107, 21);
            this.textBoxSearch.TabIndex = 36;
            // 
            // labelSearchMovie
            // 
            this.labelSearchMovie.AutoSize = true;
            this.labelSearchMovie.BackColor = System.Drawing.Color.Transparent;
            this.labelSearchMovie.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.labelSearchMovie.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSearchMovie.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelSearchMovie.Location = new System.Drawing.Point(135, 269);
            this.labelSearchMovie.Name = "labelSearchMovie";
            this.labelSearchMovie.Size = new System.Drawing.Size(64, 15);
            this.labelSearchMovie.TabIndex = 37;
            this.labelSearchMovie.Text = "Movie Id :  ";
            // 
            // labelId
            // 
            this.labelId.AutoSize = true;
            this.labelId.BackColor = System.Drawing.Color.Transparent;
            this.labelId.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.labelId.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelId.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelId.Location = new System.Drawing.Point(133, 70);
            this.labelId.Name = "labelId";
            this.labelId.Size = new System.Drawing.Size(61, 15);
            this.labelId.TabIndex = 38;
            this.labelId.Text = "Movie Id:  ";
            // 
            // textBoxId
            // 
            this.textBoxId.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxId.Location = new System.Drawing.Point(212, 64);
            this.textBoxId.Name = "textBoxId";
            this.textBoxId.Size = new System.Drawing.Size(50, 21);
            this.textBoxId.TabIndex = 10;
            this.textBoxId.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxId_KeyPress);
            // 
            // listBoxMovieInfo
            // 
            this.listBoxMovieInfo.FormattingEnabled = true;
            this.listBoxMovieInfo.Location = new System.Drawing.Point(71, 267);
            this.listBoxMovieInfo.Name = "listBoxMovieInfo";
            this.listBoxMovieInfo.Size = new System.Drawing.Size(26, 17);
            this.listBoxMovieInfo.TabIndex = 40;
            this.listBoxMovieInfo.Visible = false;
            this.listBoxMovieInfo.SelectedIndexChanged += new System.EventHandler(this.listBoxMovieInfo_SelectedIndexChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label15.Font = new System.Drawing.Font("Century Gothic", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label15.Location = new System.Drawing.Point(209, 117);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(34, 13);
            this.label15.TabIndex = 53;
            this.label15.Text = "Hours ";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label16.Font = new System.Drawing.Font("Century Gothic", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label16.Location = new System.Drawing.Point(282, 117);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(26, 13);
            this.label16.TabIndex = 54;
            this.label16.Text = "Mins";
            // 
            // comboBoxDirector
            // 
            this.comboBoxDirector.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxDirector.FormattingEnabled = true;
            this.comboBoxDirector.Location = new System.Drawing.Point(239, 131);
            this.comboBoxDirector.Name = "comboBoxDirector";
            this.comboBoxDirector.Size = new System.Drawing.Size(153, 24);
            this.comboBoxDirector.TabIndex = 55;
            // 
            // comboBoxActor
            // 
            this.comboBoxActor.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxActor.FormattingEnabled = true;
            this.comboBoxActor.Location = new System.Drawing.Point(513, 131);
            this.comboBoxActor.Name = "comboBoxActor";
            this.comboBoxActor.Size = new System.Drawing.Size(148, 24);
            this.comboBoxActor.TabIndex = 56;
            // 
            // listViewMovies
            // 
            this.listViewMovies.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeaderId,
            this.columnHeaderTitle,
            this.columnHeaderDuration,
            this.columnHeaderGenre,
            this.columnHeaderCountry,
            this.columnHeaderYear,
            this.columnHeaderDirector,
            this.columnHeaderActor,
            this.columnHeaderAudio,
            this.columnHeaderCC,
            this.columnHeaderCCLeng,
            this.columnHeaderAward});
            this.listViewMovies.Font = new System.Drawing.Font("Century Gothic", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listViewMovies.GridLines = true;
            this.listViewMovies.Location = new System.Drawing.Point(27, 324);
            this.listViewMovies.Name = "listViewMovies";
            this.listViewMovies.Size = new System.Drawing.Size(753, 147);
            this.listViewMovies.TabIndex = 57;
            this.listViewMovies.UseCompatibleStateImageBehavior = false;
            this.listViewMovies.View = System.Windows.Forms.View.Details;
            this.listViewMovies.SelectedIndexChanged += new System.EventHandler(this.listViewMovies_SelectedIndexChanged);
            // 
            // columnHeaderId
            // 
            this.columnHeaderId.Text = "Id";
            this.columnHeaderId.Width = 29;
            // 
            // columnHeaderTitle
            // 
            this.columnHeaderTitle.Text = "Title";
            this.columnHeaderTitle.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeaderTitle.Width = 95;
            // 
            // columnHeaderDuration
            // 
            this.columnHeaderDuration.Text = "Duration";
            this.columnHeaderDuration.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeaderDuration.Width = 53;
            // 
            // columnHeaderGenre
            // 
            this.columnHeaderGenre.Text = "Genre";
            this.columnHeaderGenre.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // columnHeaderCountry
            // 
            this.columnHeaderCountry.Text = "Country";
            this.columnHeaderCountry.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // columnHeaderYear
            // 
            this.columnHeaderYear.Text = "Year";
            this.columnHeaderYear.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeaderYear.Width = 33;
            // 
            // columnHeaderDirector
            // 
            this.columnHeaderDirector.Text = "Director";
            this.columnHeaderDirector.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeaderDirector.Width = 94;
            // 
            // columnHeaderActor
            // 
            this.columnHeaderActor.Text = "Actor";
            this.columnHeaderActor.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeaderActor.Width = 102;
            // 
            // columnHeaderAudio
            // 
            this.columnHeaderAudio.Text = "Audio";
            this.columnHeaderAudio.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeaderAudio.Width = 52;
            // 
            // columnHeaderCC
            // 
            this.columnHeaderCC.Text = "CC";
            this.columnHeaderCC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeaderCC.Width = 42;
            // 
            // columnHeaderCCLeng
            // 
            this.columnHeaderCCLeng.Text = "CC Leng.";
            this.columnHeaderCCLeng.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // columnHeaderAward
            // 
            this.columnHeaderAward.Text = "Award";
            this.columnHeaderAward.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeaderAward.Width = 75;
            // 
            // buttonWriteTxt
            // 
            this.buttonWriteTxt.BackColor = System.Drawing.Color.Gold;
            this.buttonWriteTxt.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonWriteTxt.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonWriteTxt.ForeColor = System.Drawing.Color.Maroon;
            this.buttonWriteTxt.Image = global::Project_Part1_Andrea_Pinilla.Properties.Resources.download;
            this.buttonWriteTxt.Location = new System.Drawing.Point(219, 490);
            this.buttonWriteTxt.Name = "buttonWriteTxt";
            this.buttonWriteTxt.Size = new System.Drawing.Size(138, 23);
            this.buttonWriteTxt.TabIndex = 58;
            this.buttonWriteTxt.Text = "Write To Text File";
            this.buttonWriteTxt.UseVisualStyleBackColor = false;
            this.buttonWriteTxt.Click += new System.EventHandler(this.buttonWriteTxt_Click);
            // 
            // buttonReadTxt
            // 
            this.buttonReadTxt.BackColor = System.Drawing.Color.Gold;
            this.buttonReadTxt.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonReadTxt.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonReadTxt.ForeColor = System.Drawing.Color.Maroon;
            this.buttonReadTxt.Image = global::Project_Part1_Andrea_Pinilla.Properties.Resources.download;
            this.buttonReadTxt.Location = new System.Drawing.Point(219, 519);
            this.buttonReadTxt.Name = "buttonReadTxt";
            this.buttonReadTxt.Size = new System.Drawing.Size(138, 23);
            this.buttonReadTxt.TabIndex = 59;
            this.buttonReadTxt.Text = "Read From Text File";
            this.buttonReadTxt.UseVisualStyleBackColor = false;
            this.buttonReadTxt.Click += new System.EventHandler(this.buttonReadTxt_Click);
            // 
            // buttonWriteToBinFIle
            // 
            this.buttonWriteToBinFIle.BackColor = System.Drawing.Color.Gold;
            this.buttonWriteToBinFIle.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonWriteToBinFIle.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonWriteToBinFIle.ForeColor = System.Drawing.Color.Maroon;
            this.buttonWriteToBinFIle.Image = global::Project_Part1_Andrea_Pinilla.Properties.Resources.download;
            this.buttonWriteToBinFIle.Location = new System.Drawing.Point(470, 490);
            this.buttonWriteToBinFIle.Name = "buttonWriteToBinFIle";
            this.buttonWriteToBinFIle.Size = new System.Drawing.Size(136, 23);
            this.buttonWriteToBinFIle.TabIndex = 60;
            this.buttonWriteToBinFIle.Text = "Write To Bin File";
            this.buttonWriteToBinFIle.UseVisualStyleBackColor = false;
            this.buttonWriteToBinFIle.Click += new System.EventHandler(this.buttonWriteToBinFIle_Click);
            // 
            // buttonReadFromBinFile
            // 
            this.buttonReadFromBinFile.BackColor = System.Drawing.Color.Gold;
            this.buttonReadFromBinFile.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonReadFromBinFile.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonReadFromBinFile.ForeColor = System.Drawing.Color.Maroon;
            this.buttonReadFromBinFile.Image = global::Project_Part1_Andrea_Pinilla.Properties.Resources.download;
            this.buttonReadFromBinFile.Location = new System.Drawing.Point(470, 519);
            this.buttonReadFromBinFile.Name = "buttonReadFromBinFile";
            this.buttonReadFromBinFile.Size = new System.Drawing.Size(136, 23);
            this.buttonReadFromBinFile.TabIndex = 61;
            this.buttonReadFromBinFile.Text = "Read From Bin File";
            this.buttonReadFromBinFile.UseVisualStyleBackColor = false;
            this.buttonReadFromBinFile.Click += new System.EventHandler(this.buttonReadFromBinFile_Click);
            // 
            // MovieLibraryForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Project_Part1_Andrea_Pinilla.Properties.Resources._31;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(806, 556);
            this.Controls.Add(this.buttonReadFromBinFile);
            this.Controls.Add(this.buttonWriteToBinFIle);
            this.Controls.Add(this.buttonReadTxt);
            this.Controls.Add(this.buttonWriteTxt);
            this.Controls.Add(this.listViewMovies);
            this.Controls.Add(this.comboBoxActor);
            this.Controls.Add(this.comboBoxDirector);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.listBoxMovieInfo);
            this.Controls.Add(this.textBoxId);
            this.Controls.Add(this.labelId);
            this.Controls.Add(this.labelSearchMovie);
            this.Controls.Add(this.textBoxSearch);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.buttonSearch);
            this.Controls.Add(this.buttonReset);
            this.Controls.Add(this.buttonDelete);
            this.Controls.Add(this.buttonUpdate);
            this.Controls.Add(this.buttonDisplay);
            this.Controls.Add(this.buttonAdd);
            this.Controls.Add(this.comboBoxAward);
            this.Controls.Add(this.labelAward);
            this.Controls.Add(this.comboBoxCCLeng);
            this.Controls.Add(this.labelCCLenguage);
            this.Controls.Add(this.comboBoxCloseCaption);
            this.Controls.Add(this.labelCloseCaption);
            this.Controls.Add(this.comboBoxLenguage);
            this.Controls.Add(this.labelLenguage);
            this.Controls.Add(this.textBoxActor);
            this.Controls.Add(this.labelActor);
            this.Controls.Add(this.textBoxDirector);
            this.Controls.Add(this.labelDirector);
            this.Controls.Add(this.textBoxYear);
            this.Controls.Add(this.labelYear);
            this.Controls.Add(this.textBoxCountry);
            this.Controls.Add(this.comboBoxGenre);
            this.Controls.Add(this.textBoxMinutes);
            this.Controls.Add(this.textBoxHours);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.labelCountry);
            this.Controls.Add(this.labelGenre);
            this.Controls.Add(this.labelDuration);
            this.Controls.Add(this.textBoxTitle);
            this.Controls.Add(this.labelTitle);
            this.Controls.Add(this.label1);
            this.Name = "MovieLibraryForm";
            this.Text = "MovieLibraryForm";
            this.Load += new System.EventHandler(this.MovieLibraryForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxTitle;
        private System.Windows.Forms.Label labelTitle;
        private System.Windows.Forms.TextBox textBoxHours;
        private System.Windows.Forms.Label labelDuration;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxMinutes;
        private System.Windows.Forms.Label labelGenre;
        private System.Windows.Forms.ComboBox comboBoxGenre;
        private System.Windows.Forms.Label labelCountry;
        private System.Windows.Forms.TextBox textBoxCountry;
        private System.Windows.Forms.Label labelYear;
        private System.Windows.Forms.TextBox textBoxYear;
        private System.Windows.Forms.Label labelDirector;
        private System.Windows.Forms.TextBox textBoxDirector;
        private System.Windows.Forms.TextBox textBoxActor;
        private System.Windows.Forms.Label labelActor;
        private System.Windows.Forms.Label labelLenguage;
        private System.Windows.Forms.ComboBox comboBoxLenguage;
        private System.Windows.Forms.Label labelCloseCaption;
        private System.Windows.Forms.ComboBox comboBoxCloseCaption;
        private System.Windows.Forms.Label labelCCLenguage;
        private System.Windows.Forms.ComboBox comboBoxCCLeng;
        private System.Windows.Forms.Label labelAward;
        private System.Windows.Forms.ComboBox comboBoxAward;
        private System.Windows.Forms.Button buttonAdd;
        private System.Windows.Forms.Button buttonDisplay;
        private System.Windows.Forms.Button buttonUpdate;
        private System.Windows.Forms.Button buttonDelete;
        private System.Windows.Forms.Button buttonReset;
        private System.Windows.Forms.Button buttonSearch;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.TextBox textBoxSearch;
        private System.Windows.Forms.Label labelSearchMovie;
        private System.Windows.Forms.Label labelId;
        private System.Windows.Forms.TextBox textBoxId;
        private System.Windows.Forms.ListBox listBoxMovieInfo;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox comboBoxDirector;
        private System.Windows.Forms.ComboBox comboBoxActor;
        private System.Windows.Forms.ListView listViewMovies;
        private System.Windows.Forms.ColumnHeader columnHeaderId;
        private System.Windows.Forms.ColumnHeader columnHeaderTitle;
        private System.Windows.Forms.ColumnHeader columnHeaderDuration;
        private System.Windows.Forms.ColumnHeader columnHeaderGenre;
        private System.Windows.Forms.ColumnHeader columnHeaderCountry;
        private System.Windows.Forms.ColumnHeader columnHeaderYear;
        private System.Windows.Forms.ColumnHeader columnHeaderDirector;
        private System.Windows.Forms.ColumnHeader columnHeaderActor;
        private System.Windows.Forms.ColumnHeader columnHeaderAudio;
        private System.Windows.Forms.ColumnHeader columnHeaderCC;
        private System.Windows.Forms.ColumnHeader columnHeaderCCLeng;
        private System.Windows.Forms.ColumnHeader columnHeaderAward;
        private System.Windows.Forms.Button buttonWriteTxt;
        private System.Windows.Forms.Button buttonReadTxt;
        private System.Windows.Forms.Button buttonWriteToBinFIle;
        private System.Windows.Forms.Button buttonReadFromBinFile;
    }
}